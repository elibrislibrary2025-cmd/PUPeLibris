<?php
// Database connection
include('connect.php');

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

// Check if the student_id is provided
if(isset($data['student_id'])) {
    $studentId = $data['student_id'];

    // Prepare the SQL query to check for existing student ID
    $query = "SELECT COUNT(*) AS count FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $studentId);  // "s" denotes string type
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();

    // Send response based on the result
    if($count > 0) {
        // Student ID exists
        echo json_encode(["exists" => true]);
    } else {
        // Student ID does not exist
        echo json_encode(["exists" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "Student ID is required."]);
}

$conn->close();
?>
