<?php
// Include the database connection file
include 'connect.php'; // Ensure this points to your actual database connection file

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Get the student ID from the POST request
if (isset($_POST['studentID'])) {
    $studentID = $_POST['studentID'];

    // Prepare a statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT name, course FROM students WHERE student_id = ?");
    $stmt->bind_param("s", $studentID); // Ensure this matches the student_id data type in your database
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a student was found
    if ($result->num_rows > 0) {
        // Fetch the student details
        $student = $result->fetch_assoc();
        // Return the student details as a JSON response
        echo json_encode(['name' => $student['name'], 'course' => $student['course']]);
    } else {
        // If no student was found, return an error message
        echo json_encode(['error' => 'Student not found']);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // If studentID is not set, return an error message
    echo json_encode(['error' => 'No student ID provided']);
}
?>
