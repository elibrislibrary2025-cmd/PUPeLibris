<?php
include 'connect.php';
header('Content-Type: application/json');
date_default_timezone_set('Asia/Manila');

// Query to get top 5 courses with most visits
$sql = "
    SELECT 
        course,
        COUNT(*) as visit_count
    FROM attendance
    WHERE course IS NOT NULL AND course != ''
    GROUP BY course
    ORDER BY visit_count DESC
    LIMIT 5
";

$result = $conn->query($sql);

$top_courses = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $top_courses[] = [
            'course' => $row['course'],
            'visit_count' => (int)$row['visit_count']
        ];
    }
}

// If less than 5 courses, pad with empty data
while (count($top_courses) < 5) {
    $top_courses[] = [
        'course' => 'N/A',
        'visit_count' => 0
    ];
}

echo json_encode([
    'success' => true,
    'courses' => $top_courses
], JSON_PRETTY_PRINT);

$conn->close();
?>

