<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PUP eLibris Attendance Monitoring</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="script/html5-qrcode.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet" />
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            overflow: hidden;
        }

        #container {
            display: flex;
            height: 100vh;
        }

        #left-section {
           width: 50%;
           height: 100vh; /* para sakto sa taas ng screen */
           background-image: url('img/lib.JPG');
           background-size: cover; /* para punuin ang area nang hindi nagdi-distort */
           background-position: center; /* para nakasentro ang image */
           background-repeat: no-repeat; /* para walang ulit ng image */
           color: white;
           padding: 2rem;
           display: flex;
           flex-direction: column;
           align-items: center;
         justify-content: center;
        }


        #right-section {
            width: 50%;
            background-color: white;
            padding: 2rem;
            overflow-y: auto;
        }

        #qr-reader {
            width: 65%;
            height: 300px;
            margin: 0 auto;
            padding: 0;
            border: 2px solid #ccc;
            box-sizing: border-box;
        }

    </style>
</head>

<body>
    <div id="container">
        <!-- Left Section -->
        <div id="left-section">
            <img src="img/PUP logo.png" alt="PUP Logo" width="150" height="150">
            <h1 class="text-3xl font-bold mb-2">PUP eLibris Library</h1>
            <p class="text-lg mb-6">Attendance Monitoring</p>
            <div class="text-lg mb-2" id="current-date"></div>
            <div class="text-5xl font-bold" id="current-time"></div>
        </div>
        <!-- Right Section -->
        <div id="right-section">
            <h2 class="text-xl font-medium mb-4">Scan QR Code:</h2>

            <!-- QR Code Scanner -->
            <div id="qr-reader-container" style="margin-top: 20px;">
                <div id="qr-reader"></div>
            </div>

            <!-- Form to submit attendance -->
            <form action="save_attendance.php" method="POST" id="attendance-form" onsubmit="return validateForm()">
                <div class="mt-4">
                    <label class="block text-gray-500 mb-2" for="manual-student-id">Student Number</label>
                    <input type="text" id="manual-student-id" name="student_id" placeholder="Enter Student ID" class="w-full border border-gray-300 p-2 rounded" oninput="debounceFetchStudentDetails()">
                    <p id="student-info" class="text-lg font-medium mt-2"></p>
                    <p id="student-course" class="text-lg"></p>
                </div>
                <div class="mt-4">
                    <label class="block text-gray-500 mb-2" for="reason">Reason for visiting the library</label>
                    <select id="reason" name="reason" class="w-full border border-gray-300 p-2 rounded">
                        <option value="">Select reason</option>
                        <option value="Study / Need of learning spaces">Study / Need of learning spaces</option>
                        <option value="Read / borrow book/s">Read / borrow book/s</option>
                        <option value="Read / borrow thesis or research works">Read / borrow thesis or research works</option>
                        <option value="Use of computer">Use of computer</option>
                        <option value="Read / borrow journal/s or magazine/s">Read / borrow journal/s or magazine/s</option>
                        <option value="Consultation">Consultation</option>
                        <option value="Review area of Alumni">Review area of Alumni</option>
                        <option value="Claim Library ID / Card">Claim Library ID / Card</option>
                        <option value="Apply Library ID / Card">Apply Library ID / Card</option>
                    </select>
                </div>

                <!-- Save Button -->
                <div class="mt-4">
                    <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let html5QrcodeScanner;
        let typingTimeout;

        // Function to display the real-time date and time
        function displayDateTime() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            const currentDate = now.toLocaleDateString('en-US', options);
            document.getElementById('current-date').textContent = currentDate;

            const timeOptions = { hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true };
            const currentTime = now.toLocaleTimeString('en-US', timeOptions);
            document.getElementById('current-time').textContent = currentTime;
        }

        setInterval(displayDateTime, 1000);

        // Debounce function to limit fetch calls
        function debounceFetchStudentDetails() {
            clearTimeout(typingTimeout);
            typingTimeout = setTimeout(function () {
                const studentID = document.getElementById('manual-student-id').value.trim();

                if (studentID) {
                    fetchStudentDetails(studentID);
                }
            }, 500);
        }

        // Fetch student details based on manual ID input
        function fetchStudentDetails(studentID) {
            if (studentID) {
                fetch('get_student_info.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `studentID=${studentID}`
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            document.getElementById('student-info').innerText = "Student not found";
                            document.getElementById('student-course').innerText = "";
                        } else {
                            document.getElementById('student-info').innerText = data.name;
                            document.getElementById('student-course').innerText = data.course;
                        }
                    })
                    .catch(error => console.error('Error:', error));
            } else {
                alert("Please enter a valid student number.");
            }
        }

        // Start QR Code Scanner
        function startQrScanner() {
            const config = {
                fps: 30,
                qrbox: 250,
                highlightScanRegion: true,
                showScanRegion: true,
                cornerColor: "#ff0000",
                borderColor: "#ff0000",
            };

            html5QrcodeScanner = new Html5QrcodeScanner("qr-reader", config);
            html5QrcodeScanner.render(onScanSuccess, onScanFailure);
        }

        // QR Scanner Success Callback
        function onScanSuccess(decodedText) {
            const idRegex = /ID:\s*([A-Za-z0-9-]+)/;

            const matches = decodedText.match(idRegex);

            if (matches && matches.length > 1) {
                const studentID = matches[1];

                // Update the manual input field with the extracted student ID
                document.getElementById('manual-student-id').value = studentID;
                fetchStudentDetails(studentID);
            } else {
                document.getElementById('student-info').innerText = "Invalid QR Code format";
                document.getElementById('student-course').innerText = "";
            }
        }

        // QR Scanner Failure Callback
        function onScanFailure(error) {
            console.warn(`QR error = ${error}`);
        }

        // Initialize QR Scanner on load
        window.onload = function () {
            startQrScanner();
        }

        // Initial call to display the date and time immediately on load
        displayDateTime();

        // Function to show the success alert and reload the page after 3 seconds
        function showSuccessAlertAndReload() {
            alert("Attendance saved successfully!");
            setTimeout(function () {
                location.reload();
            }); 
        }

        // Form submission using AJAX to handle success and show popup
        document.getElementById("attendance-form").onsubmit = function(event) {
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(document.getElementById("attendance-form"));

    fetch('save_attendance.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message and reload after 3 seconds
            showSuccessAlertAndReload();
        } else {
            alert(data.message); // Show error message
        }
    })
    .catch(error => {
        console.error("Error submitting attendance:", error);
        alert("An error occurred while saving attendance. Please try again.");
    });
};

    </script>
</body>

</html>
