<?php
date_default_timezone_set('Asia/Manila');

// Include the database connection
include("connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the POST data
    $data = json_decode(file_get_contents('php://input'), true);

    // Sanitize the inputs to prevent SQL injection
    $bookTitle = mysqli_real_escape_string($conn, $data['bookTitle']);
    $bookAuthor = mysqli_real_escape_string($conn, $data['bookAuthor']);
    $accessNumber = mysqli_real_escape_string($conn, $data['accessNumber']);
    $bookDescription = mysqli_real_escape_string($conn, $data['bookDescription']);
    $studentId = mysqli_real_escape_string($conn, $data['studentId']);
    $name = mysqli_real_escape_string($conn, $data['name']);
    $course = mysqli_real_escape_string($conn, $data['course']);
    $contactNumber = mysqli_real_escape_string($conn, $data['contactNumber']);
    $email = mysqli_real_escape_string($conn, $data['email']);
    $borrowedDate = mysqli_real_escape_string($conn, $data['borrowedDate']);
    $returnedDate = date("Y-m-d H:i:s");  // Get the current date and time for the returned date

    // SQL query to insert the data into the returned_books table
    $query = "INSERT INTO returned_books (book_title, book_author, access_number, book_description, student_id, name, course, contact_number, email, borrowed_date, returned_date)
              VALUES ('$bookTitle', '$bookAuthor', '$accessNumber', '$bookDescription', '$studentId', '$name', '$course', '$contactNumber', '$email', '$borrowedDate', '$returnedDate')";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        // Return success response
        echo json_encode(['success' => true, 'message' => 'Returned book saved successfully']);
    } else {
        // Return error message
        echo json_encode(['success' => false, 'message' => 'Error saving returned book: ' . mysqli_error($conn)]);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
