<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Include your database connection
require 'connect.php';

// Set the response type to JSON
header('Content-Type: application/json');

// Get the data sent from the JavaScript (QR code data)
$data = json_decode(file_get_contents('php://input'), true);

// Check if the data is valid
if ($data === null) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON']);
    exit;
}

// Check if the qrCodeData (Student ID) is available
if (isset($data['qrCodeData'])) {
    $studentId = $data['qrCodeData'];

    // Sanitize the studentId
    $studentId = trim($studentId);

    // Prepare the SQL query to fetch student details
    $sql = "SELECT student_id, name, course, contact, gmail FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Error preparing query']);
        exit;
    }

    // Bind the studentId parameter to the prepared statement
    $stmt->bind_param("s", $studentId);

    // Execute the query
    if ($stmt->execute()) {
        // Bind the result to variables
        $stmt->bind_result($studentId, $name, $course, $contact, $gmail);

        // Check if the student was found
        if ($stmt->fetch()) {
            // Return the student data as JSON
            echo json_encode([
                'success' => true,
                'student' => [
                    'student_id' => $studentId,
                    'name' => $name,
                    'course' => $course,
                    'contact' => $contact,
                    'gmail' => $gmail
                ]
            ]);
        } else {
            // Student not found
            echo json_encode(['success' => false, 'message' => 'Student not found']);
        }
    } else {
        // Error executing query
        error_log("Error executing query: " . $stmt->error);
        echo json_encode(['success' => false, 'message' => 'Error executing query']);
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // If no student ID is provided in the request
    echo json_encode(['success' => false, 'message' => 'No student ID provided']);
}

// Close the database connection
$conn->close();
?>
