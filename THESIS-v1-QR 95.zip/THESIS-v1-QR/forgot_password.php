<!-- forgot_password.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Reset Password</h1>
        <form method="post" action="send_reset_link.php">
            <div class="input-group">
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>
            <input type="submit" class="btn" value="Send Reset Link">
        </form>
    </div>
</body>
</html>
