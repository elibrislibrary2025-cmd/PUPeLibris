<?php

error_reporting(E_ALL); // Report all types of errors
ini_set('display_errors', 1); // Display errors on the web page

include 'connect.php';  // Include your database connection

if (!isset($conn) || $conn === null) {
    die("Connection failed: The database connection could not be established.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $redirect_url = ''; // Initialize the redirect URL variable
    $alert_message = ''; // Initialize the alert message variable

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');    

    if (isset($_POST['email']) && isset($_POST['key'])) {
        // Registration Form Handling
        $email = $_POST['email'];
        $adminKey = $_POST['key'];
        $correctKey = "12345"; // Replace with your actual admin key

        if ($adminKey !== $correctKey) {
            $alert_message = 'Invalid admin key. Please try again.';
        } else {
            // Check if the username or email already exists
            $stmt = $conn->prepare("SELECT * FROM admin WHERE username=? OR email=?");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if ($row['username'] === $username && $row['email'] === $email) {
                    $alert_message = 'Both username and email already exist.';
                } elseif ($row['username'] === $username) {
                    $alert_message = 'Username already exists. Please choose a different one.';
                } elseif ($row['email'] === $email) {
                    $alert_message = 'Email already exists. Please use a different email.';
                }
            } else {
                // Insert user into the database
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $insertStmt = $conn->prepare("INSERT INTO admin (username, password, email) VALUES (?, ?, ?)");
                $insertStmt->bind_param("sss", $username, $hashedPassword, $email);

                if ($insertStmt->execute()) {
                    $alert_message = 'Registration successful. Redirecting to index page.';
                    $redirect_url = 'index.php';
                } else {
                    $alert_message = 'Error: ' . htmlspecialchars($conn->error);
                }
            }
        }
    } else {
        // Sign-In Form Handling
        $signInStmt = $conn->prepare("SELECT * FROM admin WHERE username=?");
        $signInStmt->bind_param("s", $username);
        $signInStmt->execute();
        $result = $signInStmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc(); // Fetch user data
            if (password_verify($password, $row['password'])) {
                header("Location: home.php");
                exit();
            } else {
                error_log("Password verification failed for user: $username");
                $alert_message = 'Invalid username or password. Please try again.';
                $redirect_url = 'index.php';
            }
        } else {
            // Username does not exist
            $alert_message = 'Invalid username or password. Please try again.';
            $redirect_url = 'index.php';
        }
    }

    // Close the connection only after all database operations are complete
    if ($conn) {
        $conn->close();
    }

    // Output JavaScript to handle alert and redirection
    if ($alert_message) {
        $alert_message = htmlspecialchars($alert_message); // Escape for HTML output
        echo "<script>
            alert('$alert_message');
            " . ($redirect_url ? "window.location.href = '$redirect_url';" : "") . "
        </script>";
        exit(); // Ensure no further code is executed
    }
}
?>
