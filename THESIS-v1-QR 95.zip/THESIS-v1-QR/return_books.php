<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Returned Books</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="script/html5-qrcode.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .form-label {
            font-weight: bold;
        }
        .form-input {
            transition: border-color 0.3s;
        }
        .form-input:focus {
            border-color: #800000;
            outline: none;
        }
        .form-textarea {
            transition: border-color 0.3s;
        }
        .form-textarea:focus {
            border-color: #800000;
            outline: none;
        }
        .form-button {
            background: linear-gradient(to right, #800020, #A00030) !important;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .form-button:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .top-panel {
            background-color: #800020;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .top-panel img {
            height: 50px;
            width: auto;
        }

        .top-panel h1 {
            color: #fff;
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }
        #qr-reader-container {
            margin-top: 20px;
        }
        #qr-reader {
            width: 100%;
            height: 300px;
            border: 2px solid #ccc;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Top Panel -->
    <div class="top-panel">
        <img src="img/PUP logo.png" alt="PUP Logo">
        <h1>PUP eLibris</h1>
    </div>

    <div class="max-w-6xl mx-auto bg-white shadow-md rounded-lg p-4 flex mt-4">
        <!-- Left Panel: QR Scanner -->
        <div class="w-1/2 p-4 bg-white rounded-l-lg">
            <h2 class="text-lg font-bold text-center mb-4">Scan QR Code</h2>
            <!-- QR Code Scanner Container -->
            <div id="qr-reader-container" style="margin-top: 20px;">
                <div id="qr-reader"></div>
            </div>
        </div>

        <!-- Right Panel: Returned Book Form -->
        <div class="w-1/2 p-4 bg-gray-200 rounded-r-lg">
            <h2 class="text-lg font-bold text-center">Return Book Info</h2>
            <form id="return-form">
                <div class="mb-4">
                    <label class="block text-gray-700 form-label">Book Title:</label>
                    <input class="w-full border rounded p-2 form-input" readonly type="text" id="book-title" value=""/>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 form-label">Book Author:</label>
                    <input class="w-full border rounded p-2 form-input" readonly type="text" id="book-author" value=""/>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 form-label">Accession Number:</label>
                    <input class="w-full border rounded p-2 form-input" readonly type="text" id="access-number" value=""/>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700 form-label">Book Description:</label>
                    <textarea class="w-full border rounded p-2 form-textarea" readonly id="book-description"></textarea>
                </div>
                
                <hr class="my-4">
                <div class="mb-4">
                    <label class="block text-gray-700 form-label">Input Borrower Info</label>
                    <div class="mb-2">
                        <label class="block text-gray-700 form-label">Student ID:</label>
                        <input class="w-full border rounded p-2 form-input" placeholder="Enter Student ID" type="text" id="student-id"/>
                    </div>
                    <div class="mb-2">
                        <label class="block text-gray-700 form-label">Name:</label>
                        <input class="w-full border rounded p-2 form-input" placeholder="Enter Name" type="text" id="name"/>
                    </div>
                    <div class="mb-2">
                        <label class="block text-gray-700 form-label">Course:</label>
                        <input class="w-full border rounded p-2 form-input" placeholder="Enter Course" type="text" id="course"/>
                    </div>
                    <div class="mb-2">
                        <label class="block text-gray-700 form-label">Contact Number:</label>
                        <input class="w-full border rounded p-2 form-input" placeholder="Enter Contact Number" type="text" id="contact-number"/>
                    </div>
                    <div class="mb-2">
                        <label class="block text-gray-700 form-label">Email:</label>
                        <input class="w-full border rounded p-2 form-input" placeholder="Enter Email" type="email" id="email"/>
                    </div>
                    <div class="mb-2">
                        <label class="block text-gray-700 form-label">Borrowed Date:</label>
                        <input class="w-full border rounded p-2 form-input" placeholder="Select Borrowed Date" type="text" id="borrowed_date" />
                    </div>
                </div>
                <div class="flex justify-center mt-4">
                    <button class="text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-transform duration-300 ease-in-out form-button" id="save-btn">
                        <i class="fas fa-book-reader mr-2"></i> Return Book
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://unpkg.com/html5-qrcode/minified/html5-qrcode.min.js"></script>
    <script>
        // Function to start QR scanner
        function startQrScanner() {
            const config = {
                fps: 10,
                qrbox: 250,
                highlightScanRegion: true,
                showScanRegion: true,
            };

            const html5QrcodeScanner = new Html5QrcodeScanner("qr-reader", config);
            html5QrcodeScanner.render(onScanSuccess, onScanFailure);
        }

        // Function called when QR Code scan is successful
        function onScanSuccess(decodedText, decodedResult) {
            console.log("Scanned QR Code Data:", decodedText);

            const accessNumberMatch = decodedText.match(/AccessNumber:\s*(\S+)/i);

            if (accessNumberMatch) {
                const accessNumber = accessNumberMatch[1];

                // Fetch details of the borrowed book
                fetch('get_borrowed_book_details.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ qrCodeData: accessNumber })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Populate the fields with the fetched data
                        document.getElementById('book-title').value = data.borrowedBook.book_title || '';
                        document.getElementById('book-author').value = data.borrowedBook.book_author || '';
                        document.getElementById('access-number').value = data.borrowedBook.access_number || '';
                        document.getElementById('book-description').value = data.borrowedBook.book_description || '';
                        document.getElementById('student-id').value = data.borrowedBook.student_id || '';
                        document.getElementById('name').value = data.borrowedBook.name || '';
                        document.getElementById('course').value = data.borrowedBook.course || '';
                        document.getElementById('contact-number').value = data.borrowedBook.contact_number || '';
                        document.getElementById('email').value = data.borrowedBook.email || '';
                        document.getElementById('borrowed_date').value = data.borrowedBook.borrowed_date || '';
                    } else {
                        alert(data.message || 'Borrowed book not found!');
                    }
                })
                .catch(error => {
                    console.error('Error fetching borrowed book details:', error);
                    alert('An error occurred while fetching the borrowed book details.');
                });
            } else {
                alert("Invalid QR Code format.");
            }
        }

        function onScanFailure(error) {
            console.warn(`QR scan failed: ${error}`);
        }

        // Handle the button click to save the returned book details
        document.getElementById('save-btn').addEventListener('click', function(event) {
    event.preventDefault();  // Prevent form submission

    // Collect form data
    const bookTitle = document.getElementById('book-title').value;
    const bookAuthor = document.getElementById('book-author').value;
    const accessNumber = document.getElementById('access-number').value;
    const bookDescription = document.getElementById('book-description').value;
    const studentId = document.getElementById('student-id').value;
    const name = document.getElementById('name').value;
    const course = document.getElementById('course').value;
    const contactNumber = document.getElementById('contact-number').value;
    const email = document.getElementById('email').value;
    const borrowedDate = document.getElementById('borrowed_date').value;

    // Send the data to the server via a POST request
    fetch('save_returned_book.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            bookTitle,
            bookAuthor,
            accessNumber,
            bookDescription,
            studentId,
            name,
            course,
            contactNumber,
            email,
            borrowedDate
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Returned book saved successfully!');
            // Optionally, reset form fields after saving
            document.getElementById('return-form').reset();
        } else {
            alert('Error saving returned book: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error saving returned book:', error);
        alert('An error occurred while saving the returned book.');
    });
});


        // Start QR scanner when the page loads
        window.onload = startQrScanner;
    </script>
</body>
</html>
