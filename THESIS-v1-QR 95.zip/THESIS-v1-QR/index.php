<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PUP Santa Maria Library</title>
</head>
<body>
	

    <div class="container" id="signup"style="display: none;">
        <h1 class="form-title">Register</h1>
        <form id="registrationForm" method="post" action="register.php">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" id="username" placeholder="User Name" required>
                <label for="username">User Name</label>
            </div>
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="password" name="password" id="password" placeholder="Password" required>
                <label for="password">Password</label>
            </div>
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="email" placeholder="Email" required>
                <label for="email">Email</label>
            </div>
            <div class="input-group">
                <i class="fas fa-key"></i>
                <input type="password" name="key" id="key" placeholder="Admin Key" required>
                <label for="key">Admin Key</label>
            </div>
            <div id="error-message" style="color: red; display: none;">Invalid admin key. Please try again.</div>
            <input type="submit" class="btn" value="Sign Up">
        </form>
        <div class="links">
            <p>Already Have an Account?</p>
            <button id="signInButton">Sign In</button>
        </div>
    </div>

    <div class="container" id="signIn">
        <h1 class="form-title">Sign In</h1>
        <form method="post" action="register.php">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" id="username" placeholder="User Name" required>
                <label for="username">User Name</label>
            </div>
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="password" name="password" id="password" placeholder="Password" required>
                <label for="password">Password</label>
            </div>
            <p class="recover">
                <a href="forgot_password.php">Forgot Password?</a>
            </p>

            <input type="submit" class="btn" value="Sign In">
        </form>
        <div class="links">
            <p>Don't Have an Account Yet?</p>
            <button id="signUpButton">Sign Up</button>
        </div>
    </div>
    <script src="script/loginscript.js"></script>
</body>
</html>
