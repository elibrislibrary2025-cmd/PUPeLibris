<?php
// Enable error reporting (Remove or comment out this in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'connect.php';  // Include your database connection

// Check if the connection was successful
if (!isset($conn) || $conn === null) {
    die("Connection failed: The database connection could not be established.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email from the POST request and sanitize it
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);

    // Validate the email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format.'); window.location.href = 'forgot_password.php';</script>";
        exit();
    }

    // Prepare the SQL statement to check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM admin WHERE email=?");
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error . "<br>";
        exit();
    }

    // Bind the email parameter and execute the statement
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a user with the provided email exists
    if ($result->num_rows > 0) {
        // Email exists, proceed to send the reset link
        $token = bin2hex(random_bytes(16)); // Generate a random token

        // Save the token in the database
        $insertTokenSql = "INSERT INTO reset_tokens (email, token) VALUES (?, ?)";
        $tokenStmt = $conn->prepare($insertTokenSql);
        if ($tokenStmt === false) {
            echo "Error preparing token statement: " . $conn->error . "<br>";
            exit();
        }

        $tokenStmt->bind_param("ss", $email, $token);
        $tokenStmt->execute();
        $tokenStmt->close();

        // Prepare the reset link
        $resetLink = "http://yourwebsite.com/reset_password.php?token=" . $token;

        // Send email
        $subject = "Password Reset Request";
        $message = "Click the following link to reset your password: " . $resetLink;
        $headers = "From: no-reply@yourwebsite.com";

        if (mail($email, $subject, $message, $headers)) {
            echo "<script>alert('A password reset link has been sent to your email.'); window.location.href = 'index.php';</script>";
        } else {
            echo "<script>alert('Failed to send the email. Please try again later.'); window.location.href = 'forgot_password.php';</script>";
        }
    } else {
        echo "<script>alert('No user found with that email address.'); window.location.href = 'forgot_password.php';</script>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
