<?php
header(header: "Content-Type: application/json");

// Include database connection
include 'connect.php';

$input = json_decode(json: file_get_contents(filename: "php://input"), associative: true);

if (isset($input['save_student'])) {
    $name = $input['name'];
    $id = $input['id'];
    $course = $input['course'];
    $contact = $input['contact'];
    $gmail = $input['gmail'];
    $qrCode = $input['qrCode'];

    $stmt = $conn->prepare(query: "INSERT INTO students (name, student_id, course, contact, gmail, qrCode) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $id, $course, $contact, $gmail, $qrCode);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$conn->close();
?>
