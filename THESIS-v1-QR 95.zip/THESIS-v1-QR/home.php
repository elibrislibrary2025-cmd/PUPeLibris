
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tags for character encoding and responsiveness -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PUP eLibris</title>

  <!-- External CSS for styling -->
   <!-- <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"> -->

  <link href="css/homestyle.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
  <!-- Top navigation panel with logo and logout button -->
  <div class="top-panel">
    <div class="left-section">
      <img src="img/PUP logo.PNG" alt="Logo" class="logo">
      <h1>PUP eLibris</h1>
    </div>
    <button id="logout-btn" aria-label="Log Out">
      <i class="fas fa-sign-out-alt"></i> Log Out
    </button>
    <script>
      // Logout functionality
      document.getElementById('logout-btn').addEventListener('click', function() {
        window.location.href = 'logout.php'; // Redirect to logout page
      });
    </script>
  </div>

  <div class="container">
    <!-- Side navigation panel with buttons for different sections -->
    <div class="side-panel">
      <button id="dashboard-btn" class="active" onclick="showPanel('dashboard')">Dashboard</button>
      <button id="book-circulation-btn" onclick="showPanel('book-circulation')">Book Circulation</button>  
      <button id="attendance-btn" onclick="showPanel('attendance')">Student Library Attendance</button>
      <button id="book-qr-generator-btn" onclick="showPanel('book-qr-generator')">Book QR Code Generator</button>
      <button id="student-qr-generator-btn" onclick="showPanel('student-qr-generator')">Student QR Code Generator</button>
      <button id="book-inventory-btn" onclick="showPanel('book-inventory')">Book Inventory</button>
      <button id="student-list-btn" onclick="showPanel('student-list')">Student List</button>
      <button id="archieve-books-btn" onclick="showPanel('archieve-books')">Due Date</button>
    </div>

    <!-- Main content section for the selected panel -->
    <div class="main-content">
      <!-- Dashboard section -->
      <div id="dashboard" class="panel active">
        <header>
          <h1>Dashboard</h1>
          <p>Overview of library system</p>
        </header>
        <div class="grid grid-cols-2 gap-4 px-4">
<?php
// Include database connection
include('connect.php');

// Query to count books
$query = "SELECT COUNT(*) AS book_count FROM books";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$book_count = $row['book_count'];
?>

<!-- No. of Books -->
<!-- <div class="card-container"> -->
<div class="bg-gray-200 p-4 rounded shadow-md flex items-center justify-between">
    <div>
        <span class="text-sm font-semibold">No. Of Books</span>
        <div class="border-t-4 border-red-500 mt-2"></div>
        <div class="flex justify-center items-center mt-4">
            <i class="fas fa-book fa-2x text-gray-500"></i>
            <span class="text-2xl font-bold ml-2"><?php echo $book_count; ?></span>
        </div>
    </div>
</div>

<?php
// Include database connection
include('connect.php');

// Query to count students
$query = "SELECT COUNT(*) AS student_count FROM students";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$student_count = $row['student_count'];
?>

<!-- No. Of Students -->
<div class="bg-gray-200 p-4 rounded shadow-md flex items-center justify-between">
    <div>
        <span class="text-sm font-semibold">No. Of Students</span>
        <div class="border-t-4 border-blue-500 mt-2"></div>
        <div class="flex justify-center items-center mt-4">
            <i class="fas fa-users fa-2x text-gray-500"></i>
            <span class="text-2xl font-bold ml-2"><?php echo $student_count; ?></span>
        </div>
    </div>
</div>

<?php
// Include database connection
include('connect.php');

// Query to count issued books
$query = "SELECT COUNT(*) AS issued_books_count FROM borrowed_books";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$issued_books_count = $row['issued_books_count'];
?>

<!-- Issued Books -->
<div class="bg-gray-200 p-4 rounded shadow-md flex items-center justify-between">
    <div>
        <span class="text-sm font-semibold">Issued Books</span>
        <div class="border-t-4 border-red-500 mt-2"></div>
        <div class="flex justify-center items-center mt-4">
            <i class="fas fa-book-reader fa-2x text-gray-500"></i>
            <span class="text-2xl font-bold ml-2"><?php echo $issued_books_count; ?></span>
        </div>
    </div>
</div>


    <!-- Returned Books -->
    <?php
// Include database connection
include('connect.php');

// Query to count returned books
$query = "SELECT COUNT(*) AS returned_books_count FROM returned_books";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$returned_books_count = $row['returned_books_count'];
?>

<!-- Returned Books -->
<div class="bg-gray-200 p-4 rounded shadow-md flex items-center justify-between">
    <div>
        <span class="text-sm font-semibold">Returned Books</span>
        <div class="border-t-4 border-green-500 mt-2"></div>
        <div class="flex justify-center items-center mt-4">
            <i class="fas fa-undo fa-2x text-gray-500"></i>
            <span class="text-2xl font-bold ml-2"><?php echo $returned_books_count; ?></span>
        </div>
    </div>
</div>

</div>


        <div class="dashboard-buttons">
        <button onclick="window.open('attendance.php')">Attendance</button>
        <button onclick="window.open('book_borrow.html')">Borrow Book</button>
        <button onclick="window.open('return_books.php')">Return Book</button>
        <button onclick="window.open('report.php')">Reports</button>
       

        </div>
      </div>

      
    <!-- Student Attendance -->
   <div id="attendance" class="panel">
    <header>
        <h1>Student Library Attendance</h1>
        <p>List of students who have scanned their QR codes</p>
    </header>

    <!-- Search bar -->
    <input type="text" id="attendance-search" placeholder="Search Student ID or Name" 
           style="margin-bottom:10px; padding:5px; width:100%;">

    <div id="attendance-content" class="scrollable-table">
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Course</th>
                    <th>Reason</th>
                    <th>Attendance Date</th>
                    <th>Attendance Time</th>
                </tr>
            </thead>
            <tbody id="attendance-list">
                <?php include 'fetch-attendance.php'; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('attendance-search');
    const tableBody = document.getElementById('attendance-list');

    searchInput.addEventListener('keyup', function() {
        const filter = searchInput.value.toLowerCase();

        Array.from(tableBody.getElementsByTagName('tr')).forEach(row => {
            const studentID = row.getElementsByTagName('td')[0].textContent.toLowerCase();
            const name = row.getElementsByTagName('td')[1].textContent.toLowerCase();

            // Kung ang input ay hindi nagmatch sa student ID o name, itatago yung row
            if (studentID.includes(filter) || name.includes(filter)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
});
</script>

     <!-- Book Circulation Section -->
<div class="panel" id="book-circulation">
    <header>
        <h1>Book Circulation</h1>
        <p>List of borrowed and returned books</p>
    </header>

    <!-- Search Input -->
    <input type="text" id="borrowed-search" placeholder="Search by Student ID or Accession Number" 
           class="search-input" style="margin-bottom: 10px; padding:5px; width:100%;">

    <!-- Borrowed Books Table -->
    <div id="book-list">
        <h3>Borrowed Books</h3>
        <table border="1">
            <thead>
                <tr>
                    <th>Book Title</th>
                    <th>Book Author</th>
                    <th>Access Number</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Course</th>
                    <th>Email</th>
                    <th>Borrowed Date</th>
                </tr>
            </thead>
            <tbody id="book-circulation-list">
                <?php include 'fetch-borrowed-books.php'; ?>
            </tbody>
        </table>
    </div>

    <!-- Returned Books Table -->
    <div id="returned-book-list" style="margin-top: 30px;">
        <h3>Returned Books</h3>
        <div class="scrollable-table">
            <table border="1">
                <thead>
                    <tr>
                        <th>Book Title</th>
                        <th>Book Author</th>
                        <th>Access Number</th>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Email</th>
                        <th>Borrowed Date</th>
                        <th>Returned Date</th>
                    </tr>
                </thead>
                <tbody id="returned-book-circulation-list">
                    <?php include 'fetch-returned-books.php'; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ✅ Search Functionality (Student ID + Accession Number) -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('borrowed-search');
        const borrowedTable = document.getElementById('book-circulation-list');
        const returnedTable = document.getElementById('returned-book-circulation-list');

        searchInput.addEventListener('keyup', function() {
            const filter = searchInput.value.toLowerCase();

            // Filter Borrowed Books
            Array.from(borrowedTable.getElementsByTagName('tr')).forEach(row => {
                const studentIDCell = row.getElementsByTagName('td')[3]; // Student ID column
                const accessionCell = row.getElementsByTagName('td')[2]; // Access Number column
                if (studentIDCell && accessionCell) {
                    const studentText = studentIDCell.textContent.toLowerCase();
                    const accessionText = accessionCell.textContent.toLowerCase();
                    // Show if matches either Student ID or Access Number
                    row.style.display = (studentText.includes(filter) || accessionText.includes(filter)) ? '' : 'none';
                }
            });

            // Filter Returned Books
            Array.from(returnedTable.getElementsByTagName('tr')).forEach(row => {
                const studentIDCell = row.getElementsByTagName('td')[3]; // Student ID column
                const accessionCell = row.getElementsByTagName('td')[2]; // Access Number column
                if (studentIDCell && accessionCell) {
                    const studentText = studentIDCell.textContent.toLowerCase();
                    const accessionText = accessionCell.textContent.toLowerCase();
                    row.style.display = (studentText.includes(filter) || accessionText.includes(filter)) ? '' : 'none';
                }
            });
        });
    });
    </script>

    <!-- Button Container -->
    <div id="button-container" style="margin-top: 20px;">
        <button onclick="window.open('book_borrow.html')">Borrow Book</button>
        <button onclick="window.open('return_books.php')">Return Book</button>
        <button onclick="window.open('due_date.php')">View Due Date</button>
    </div>
</div>


      <!-- Book QR Code Generator Section -->
      <div id="book-qr-generator" class="panel">
        <header>
          <h1>Book QR Code Generator</h1>
          <p>Generate QR Code for Book</p>
        </header>
        <div class="form">
        <label for="book-title">Book Title:</label>
          <input type="text" id="book-title" placeholder="e.g., Introduction to Web Development" maxlength="50" required>
          <label for="book-author">Book Author:</label>
          <input type="text" id="book-author" placeholder="e.g., Jane Doe" maxlength="50" required>
          <label for="access-number">Book Accession:</label>
          <input type="number" id="access-number" placeholder="e.g., 100123456" maxlength="9" required>
          <label for="book-description">Book Description:</label>
          <textarea id="book-description" placeholder="e.g., A beginner-friendly guide to creating and managing websites using modern tools and techniques." maxlength="500" required></textarea>
          <button id="generate-book-qr">Generate QR Code</button>
        </div>
        <div class="qr-code">
          <img id="book-qrImage" src="" alt="Generated QR code for book details">
        </div>
      </div>

      <!-- Student QR Code Generator Section -->
      <div id="student-qr-generator" class="panel">
        <header>
          <h1>Student QR Code Generator</h1>
          <p>Generate QR Code for Student</p>
        </header>
       <style>
  .form label {
    display: block;
    margin-top: 10px; /* nagbibigay ng tamang agwat bawat label */
    font-weight: 600;
  }

  .form input,
  .form select {
    width: 100%;
    padding: 6px;
    margin-top: 4px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 5px;
  }

  .form button {
    margin-top: 15px;
    padding: 8px 12px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  .form button:hover {
    background-color: #0056b3;
  }
</style>

<div class="form">
  <label for="student-name">Full Name:</label>
  <input type="text" id="student-name" placeholder="e.g., Smith, John A." maxlength="50" required>

  <label for="student-id">Student ID:</label>
  <input type="text" id="student-id" placeholder="e.g., 2021-0123" maxlength="15" required>

  <label for="student-course">Course:</label>
  <select id="student-course" required>
    <option value="">-- Select Course --</option>
    <option value="BSIT">Bachelor of Science in Information Technology</option>
    <option value="BSCpE">Bachelor of Science in Computer Engineering</option>
    <option value="BSA">Bachelor of Science in Accountancy</option>
    <option value="BSHM">Bachelor of Science in Hospitality Management</option>
    <option value="BSEntrep">Bachelor of Science in Entrepreneurship</option>
    <option value="BSE-English">Bachelor of Secondary Education Major in English</option>
    <option value="BSE-Math">Bachelor of Secondary Education Major in Mathematics</option>
    <option value="DOMT-Legal">Diploma in Office Management Technology with Specialization in Legal Office Management</option>
  </select>

  <label for="student-contact">Contact No:</label>
  <input type="text" id="student-contact" placeholder="e.g., 09123456789" maxlength="11" pattern="\d{11}" required>

  <label for="student-gmail">Email:</label>
  <input type="email" id="student-gmail" placeholder="e.g., john.smithexample@gmail.com" maxlength="50" required>

  <button id="generate-student-qr">Generate QR Code</button>
</div>


        <div class="qr-code">
          <img id="student-qrImage" src="" alt="Generated QR code for student details">
        </div>
      </div>

     <!-- Book Inventory Section -->
<div id="book-inventory" class="panel">
  <header>
    <h1>Book Inventory</h1>
    <p>List of books with QR codes</p>
  </header>
  
  <!-- Search Input -->
  <input type="text" id="inventory-search" placeholder="Search by Accession Number" 
         class="search-input" style="margin-bottom: 10px; padding:5px; width:100%;">

  <!-- Scrollable Table Wrapper -->
  <div class="scrollable-table">
    <table id="inventory-table">
      <tbody>
        <tr>
          <td class="details-container">
            <span id="book-author-display">Author Name</span>
          </td>
          <td>
            <img src="path/to/book-qr-code.png" alt="QR Code" class="qr-code">
          </td>
          <td class="button-container">
            <button class="details-btn">Details</button>
            <button class="delete-btn">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

      <!-- Student List Section -->
      <div id="student-list" class="panel">
        <header>
          <h1>Student List</h1>
          <p>List of students with QR codes</p>
        </header>
        
          <!-- Scrollable Table Wrapper -->
          <div class="scrollable-table">
        <table id="student-table">
          <tbody>
            <tr>
              <td class="details-container">
                <span id="student-name-display">Student Name</span>
              </td>
              <td>
                <img src="path/to/qr-code.png" alt="QR Code" class="qr-code">
              </td>
              <td class="button-container">
                <button class="details-btn">Details</button>
                <button class="delete-btn">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
          </div>
      </div>

      <!-- Notification Panel -->
<div class="panel" id="archieve-books">
  <header>
    <h1>Due Date</h1>
    <p>List of borrowed books</p>
  </header>

  <div class="scrollable-table" style="max-height:400px; overflow-y:auto; margin-top:10px;">
    <table border="1" style="width:100%; border-collapse:collapse;">
      <thead>
        <tr>
          <th>Student ID</th>
          <th>Name</th>
          <th>Book Title</th>
          <th>Book Author</th>
          <th>Access Number</th>
          <th>Borrowed Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        include 'connect.php';

        // Fetch all borrowed books that are not yet returned
        $query = "SELECT * FROM borrowed_books ORDER BY borrowed_date DESC";
        $result = $conn->query($query);

        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                echo "<tr>
                        <td>{$row['student_id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['book_title']}</td>
                        <td>{$row['book_author']}</td>
                        <td>{$row['access_number']}</td>
                        <td>{$row['borrowed_date']}</td>
                        <td>
                          <button class='send-reminder' 
                                  data-email='{$row['email']}' 
                                  data-name='{$row['name']}' 
                                  data-book='{$row['book_title']}'>
                                  Send Reminder
                          </button>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No borrowed books found</td></tr>";
        }

        $conn->close();
        ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Optional JavaScript for sending reminder -->

    </div>
  </div>

  <!-- Details View Modal for additional content -->
  <div class="modal" id="myModal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <div class="modal-body">
        <h3>Modal Header</h3>
        <p>This is a modal content area.</p>
        <img src="img/sample-image.png" alt="Sample Image inside modal">
      </div>
    </div>
  </div>

  <!-- QR code generation library -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

  <!-- External JavaScript for page functionality -->
  <script src="script/homescript.js" defer></script>

<!-- Book Inventory Search Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const inventorySearch = document.getElementById('inventory-search');
    const inventoryTable = document.querySelector('#inventory-table tbody');

    inventorySearch.addEventListener('keyup', function() {
        const filter = inventorySearch.value.trim();
        let found = false; // Track if any book matches

        // Loop through table rows
        Array.from(inventoryTable.getElementsByTagName('tr')).forEach(row => {
            const accessNumberBtn = row.querySelector('.details-btn'); // get access number from button
            if (accessNumberBtn) {
                const accessNumber = accessNumberBtn.getAttribute('data-access-number');
                if (accessNumber === filter || filter === '') {
                    row.style.display = '';
                    found = true;
                } else {
                    row.style.display = 'none';
                }
            }
        });

        // Optional: log if no match
        if (!found && filter !== '') {
            console.log("No book found with this Accession Number.");
        }
    });
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.send-reminder');

    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const email = this.getAttribute('data-email');
            const name = this.getAttribute('data-name');
            const book = this.getAttribute('data-book');

            // Send reminder using AJAX
            fetch('send_reminder.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `email=${encodeURIComponent(email)}&name=${encodeURIComponent(name)}&book=${encodeURIComponent(book)}`
            })
            .then(response => response.json())
            .then(data => {
                if(data.success){
                    alert(`Reminder sent to ${name} (${email}) for book: ${book}`);
                } else {
                    alert('Error sending reminder: ' + data.message);
                }
            })
            .catch(err => console.error(err));
        });
    });

    // Filter/search by student name or ID
    const searchInput = document.getElementById('notification-search');
    const tableBody = document.getElementById('notification-list');

    searchInput.addEventListener('keyup', function() {
        const filter = searchInput.value.toLowerCase();

        Array.from(tableBody.getElementsByTagName('tr')).forEach(row => {
            const studentID = row.getElementsByTagName('td')[3].textContent.toLowerCase();
            const name = row.getElementsByTagName('td')[4].textContent.toLowerCase();

            if(studentID.includes(filter) || name.includes(filter)){
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
});
</script>
</body>
</html>
