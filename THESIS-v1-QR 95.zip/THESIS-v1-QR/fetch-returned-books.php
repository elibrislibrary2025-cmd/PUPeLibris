<?php
include 'connect.php'; // Ensure this connects to your database

// Fetch returned books with the most recently returned first
$query = "SELECT 
    book_title, book_author, access_number, 
    student_id, name, course, email, borrowed_date, returned_date 
    FROM returned_books
    ORDER BY returned_date DESC"; // Sorting: latest returned first

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['book_title']}</td>
            <td>{$row['book_author']}</td>
            <td>{$row['access_number']}</td>
            <td>{$row['student_id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['course']}</td>
            <td>{$row['email']}</td>
            <td>{$row['borrowed_date']}</td>
            <td>{$row['returned_date']}</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='9'>No returned books found</td></tr>";
}

$conn->close();
?>
