<?php
// send_reminder.php

// Ensure JSON response
header('Content-Type: application/json');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Simple input retrieval and validation
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$name  = isset($_POST['name']) ? trim($_POST['name']) : '';
$book  = isset($_POST['book']) ? trim($_POST['book']) : '';

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid or missing email']);
    exit;
}

if ($name === '' || $book === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing name or book']);
    exit;
}

// Include PHPMailer classes (no Composer)
// Path assumes: THESIS-v1-QR/PHPMailer-master/src exists
require_once __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// SMTP configuration — fill with your SMTP provider credentials
$smtpHost = 'smtp.gmail.com';    // e.g., smtp.gmail.com
$smtpPort = 587;                 // 587 (TLS) or 465 (SSL)
$smtpUser = 'elibrislibrary2025@gmail.com'; // your SMTP username/email
$smtpPass = 'gfhi kzwa hpzg hsle';      // your SMTP/app password
$fromEmail = 'elibrislibrary2025@gmail.com';
$fromName  = 'PUP eLibris';

// Compose email
$subject = 'Library Book Due Reminder';
$bodyText = "Hello {$name},\n\nThis is a friendly reminder that the book \"{$book}\" you borrowed from the library is due soon.\nPlease return it to avoid any late penalties.\n\nThank you,\nLibrary Staff";

// Try to embed the PUP logo if available
$logoCid = null;
$candidateLogos = [
    __DIR__ . '/img/PUP logo.png',
    __DIR__ . '/img/PUP logo.PNG',
    __DIR__ . '/PUP logo.png',
    __DIR__ . '/PUP logo.PNG',
];
foreach ($candidateLogos as $logoPath) {
    if (file_exists($logoPath)) {
        $logoCid = 'pup_logo';
        break;
    }
}

// Build formal maroon-themed HTML body
$brandMaroon = '#7c0a02';
$bodyHtml = ""
    . '<!DOCTYPE html>'
    . '<html>'
    . '<head>'
    . '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />'
    . '<meta name="viewport" content="width=device-width, initial-scale=1.0" />'
    . '<style type="text/css">'
    . 'body{margin:0;padding:0;background:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#222}'
    . '.container{max-width:640px;margin:0 auto;border:1px solid #eee;border-radius:8px;overflow:hidden}'
    . '.header{display:flex;align-items:center;gap:12px;padding:16px 20px;background:' . $brandMaroon . ';color:#fff}'
    . '.header h1{margin:0;font-size:20px;font-weight:700;letter-spacing:.4px}'
    . '.logo{width:44px;height:44px;object-fit:contain;border-radius:50%;background:#fff;padding:2px}'
    . '.content{padding:20px}'
    . '.btn{display:inline-block;background:' . $brandMaroon . ';color:#fff;text-decoration:none;padding:10px 16px;border-radius:6px;margin-top:14px}'
    . '.muted{color:#666;font-size:12px}'
    . '.divider{height:3px;background:' . $brandMaroon . ';opacity:.85}'
    . '</style>'
    . '</head>'
    . '<body>'
    . '<div class="container">'
    . '<div class="header">'
    . ($logoCid ? '<img src="cid:' . $logoCid . '" alt="PUP" class="logo" />' : '')
    . '<h1>PUP eLibris</h1>'
    . '</div>'
    . '<div class="divider"></div>'
    . '<div class="content">'
    . '<p>Dear ' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . ',</p>'
    . '<p>This is a formal reminder that the book <strong>' . htmlspecialchars($book, ENT_QUOTES, 'UTF-8') . '</strong> you borrowed from the library is now due. Kindly return it at the soonest possible time to avoid late penalties.</p>'
    . '<p>If you have already returned the book, please disregard this message.</p>'
    . '<p>Thank you for your prompt attention.</p>'
    . '<p>Respectfully,<br/>Library Staff<br/>Polytechnic University of the Philippines</p>'
    . '<p class="muted">This is an automated notice from PUP eLibris.</p>'
    . '</div>'
    . '</div>'
    . '</body>'
    . '</html>';

$mail = new PHPMailer(true);

try {
    // Primary attempt: TLS on 587 (common for Gmail)
    $mail->isSMTP();
    $mail->Host       = $smtpHost;
    $mail->SMTPAuth   = true;
    $mail->Username   = $smtpUser;
    // Normalize Gmail app password in case it's pasted with spaces
    $mail->Password   = str_replace(' ', '', $smtpPass);
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = $smtpPort; // expected 587
    // Relax SSL verification for local dev environments (Windows/XAMPP OpenSSL CA issues)
    $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ],
    ];

    // Sender/recipient
    $mail->setFrom($fromEmail, $fromName);
    $mail->addAddress($email, $name);
    $mail->addReplyTo($fromEmail, $fromName);
    $mail->CharSet = 'UTF-8';
    if ($logoCid && isset($logoPath)) {
        $mail->addEmbeddedImage($logoPath, $logoCid);
    }

    // Content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $bodyHtml;
    $mail->AltBody = $bodyText;

    // Send
    $mail->send();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    // Fallback attempt: SMTPS on 465
    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = $smtpHost;
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtpUser;
        $mail->Password   = str_replace(' ', '', $smtpPass);
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true,
            ],
        ];

        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($email, $name);
        $mail->addReplyTo($fromEmail, $fromName);
        $mail->CharSet = 'UTF-8';
        if ($logoCid && isset($logoPath)) {
            $mail->addEmbeddedImage($logoPath, $logoCid);
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $bodyHtml;
        $mail->AltBody = $bodyText;

        $mail->send();
        echo json_encode(['success' => true, 'fallback' => true]);
    } catch (Exception $e2) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Mailer Error: ' . $e2->getMessage(),
        ]);
    }
}

?>


