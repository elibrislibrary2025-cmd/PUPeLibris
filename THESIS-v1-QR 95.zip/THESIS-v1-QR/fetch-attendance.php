<?php
include 'connect.php';

$query = "SELECT 
    `student_id`, `name`, `course`, `reason`, `attendance_date`, `attendance_time` 
    FROM `attendance` 
    ORDER BY `attendance_date` DESC, `attendance_time` DESC";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['student_id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['course']}</td>
            <td>{$row['reason']}</td>
            <td>{$row['attendance_date']}</td>
            <td>{$row['attendance_time']}</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No attendance records found</td></tr>";
}

$conn->close();
?>
