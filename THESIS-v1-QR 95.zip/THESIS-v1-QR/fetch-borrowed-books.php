<?php
include 'connect.php'; // database connection

// Kunin lahat ng borrowed books (walang limit, lahat ng records)
$query = "
SELECT * 
FROM borrowed_books
ORDER BY borrowed_date DESC
";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['book_title']}</td>
            <td>{$row['book_author']}</td>
            <td>{$row['access_number']}</td>
            <td>{$row['student_id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['course']}</td>
            <td>{$row['email']}</td>
            <td>{$row['borrowed_date']}</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='8'>No borrowed books found</td></tr>";
}

$conn->close();
?>
