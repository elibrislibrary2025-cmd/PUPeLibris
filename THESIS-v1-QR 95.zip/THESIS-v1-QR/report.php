<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Statistical Report</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #fff;
      color: #000;
      position: relative;
    }

    .top-panel {
      background-color: #800020;
      padding: 15px 20px;
      display: flex;
      align-items: center;
      gap: 15px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .top-panel img {
      height: 50px;
      width: auto;
    }

    .top-panel h1 {
      color: #fff;
      margin: 0;
      font-size: 24px;
      font-weight: bold;
    }

    .content-wrapper {
      margin: 40px;
      position: relative;
    }

    .top-right {
      position: absolute;
      top: 0;
      right: 0;
      display: flex;
      gap: 10px;
      align-items: center;
    }

    select, button {
      padding: 5px 10px;
      font-size: 14px;
      cursor: pointer;
    }

    h2, h3 {
      text-align: center;
      margin: 0;
      padding: 0;
    }

    h2 {
      font-weight: bold;
      margin-bottom: 5px;
    }

    h3 {
      font-weight: normal;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      border: 1px solid #000;
      margin-bottom: 20px;
    }

    th, td {
      border: 1px solid #000;
      text-align: center;
      padding: 8px;
      vertical-align: middle;
      height: 35px;
      word-wrap: break-word;
    }

    th {
      font-weight: bold;
    }

    /* Monthly Table: wider Course/Program column */
    #monthlyReportTable th:first-child,
    #monthlyReportTable td:first-child {
      width: 300px;
      text-align: left;
      white-space: normal;
    }

    /* Time Table */
    #timeReportTable th:first-child,
    #timeReportTable td:first-child {
      width: 130px;
      text-align: left;
      font-weight: bold;
    }

    tr:last-child td:first-child {
      font-weight: bold;
    }

    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      right: 0;
      background-color: #f9f9f9;
      min-width: 140px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
      z-index: 1;
    }

    .dropdown-content button {
      width: 100%;
      border: none;
      background: white;
      text-align: left;
      padding: 8px 12px;
    }

    .dropdown-content button:hover {
      background-color: #eee;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }
  </style>
</head>
<body>
  <div class="top-panel">
    <img src="img/PUP logo.png" alt="PUP Logo">
    <h1>PUP eLibris</h1>
  </div>

  <div class="content-wrapper">
  <div class="top-right">
    <button id="rankingsBtn" onclick="openRankingsModal()">Rankings</button>
    <select id="reportType">
      <option value="monthly">Monthly Report</option>
      <option value="time">By Time Report</option>
    </select>

    <div class="dropdown">
      <button>Download ▼</button>
      <div class="dropdown-content">
        <button id="downloadPDF">Download as PDF</button>
        <button id="downloadExcel">Download as Excel</button>
      </div>
    </div>
  </div>

  <h2 id="reportTitle">Monthly Statistical Report</h2>
  <h3 id="year"></h3>

  <!-- Monthly Report Table -->
  <table id="monthlyReportTable">
    <thead>
      <tr>
        <th>Course<br>/<br>Program</th>
        <th>January</th>
        <th>February</th>
        <th>March</th>
        <th>April</th>
        <th>May</th>
        <th>June</th>
        <th>July</th>
        <th>August</th>
        <th>September</th>
        <th>October</th>
        <th>November</th>
        <th>December</th>
      </tr>
    </thead>
    <tbody>
      <tr><td>Bachelor of Science in Information Technology</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>Bachelor of Science in Computer Engineering</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>Bachelor of Science in Accountancy</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>Bachelor of Science in Hospitality Management</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>Bachelor of Science in Entrepreneurship</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>Bachelor of Secondary Education Major in English</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>Bachelor of Secondary Education Major in Mathematics</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>Diploma in Office Management Technology<br>with Specialization in Legal Office Management</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>TOTAL</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    </tbody>
  </table>

  <!-- By Time Report -->
  <table id="timeReportTable" style="display:none;">
    <thead>
      <tr>
        <th>TIME</th>
        <th>January</th>
        <th>February</th>
        <th>March</th>
        <th>April</th>
        <th>May</th>
        <th>June</th>
        <th>July</th>
        <th>August</th>
        <th>September</th>
        <th>October</th>
        <th>November</th>
        <th>December</th>
      </tr>
    </thead>
    <tbody>
      <tr><td>8:00 - 9:00 AM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>9:01 - 10:00 AM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>10:01 - 11:00 AM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>11:01 - 12:00 NN</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>12:01 - 1:00 PM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>1:01 - 2:00 PM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>2:01 - 3:00 PM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>3:01 - 4:00 PM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>4:01 - 5:00 PM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr><td>5:01 - 6:00 PM</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
     
      <tr><td>TOTAL</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    </tbody>
  </table>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>
  // Auto current year
  document.getElementById('year').textContent = new Date().getFullYear();

  const reportType = document.getElementById('reportType');
  const titleElement = document.getElementById('reportTitle');
  const monthlyTable = document.getElementById('monthlyReportTable');
  const timeTable = document.getElementById('timeReportTable');

  // Mapping of acronyms to full course names (para mag-match sa table)
  const courseMap = {
    "BSIT": "Bachelor of Science in Information Technology",
    "BSCPE": "Bachelor of Science in Computer Engineering",
    "BSA": "Bachelor of Science in Accountancy",
    "BSHM": "Bachelor of Science in Hospitality Management",
    "BSENTREP": "Bachelor of Science in Entrepreneurship",
    "BSE-ENGLISH": "Bachelor of Secondary Education Major in English",
    "BSE-MATH": "Bachelor of Secondary Education Major in Mathematics",
    "DOMT-LEGAL": "Diploma in Office Management Technology\nwith Specialization in Legal Office Management"
  };

  // Switch between Monthly and By Time reports
  reportType.addEventListener('change', function() {
    if (this.value === 'monthly') {
      titleElement.textContent = 'Monthly Statistical Report';
      monthlyTable.style.display = '';
      timeTable.style.display = 'none';
    } else {
      titleElement.textContent = 'Monthly Statistical Report (By Time)';
      monthlyTable.style.display = 'none';
      timeTable.style.display = '';
    }
  });

  // ✅ Fetch and display attendance data
  fetch('get_attendance_report.php')
    .then(res => res.json())
    .then(data => {
      const monthlyData = data.monthly;
      const timeData = data.time;

      // -------------------------------
      // Fill MONTHLY REPORT
      // -------------------------------
      const monthlyRows = document.querySelectorAll('#monthlyReportTable tbody tr');
      monthlyRows.forEach(row => {
        const courseFull = row.cells[0].innerText.trim();
        if (courseFull.toLowerCase().includes('total')) return;

        const courseAcronym = Object.keys(courseMap).find(key => courseMap[key] === courseFull);
        const courseData = courseAcronym ? monthlyData[courseAcronym] : null;

        for (let m = 1; m <= 12; m++) {
          const count = (courseData && courseData[m]) ? courseData[m] : 0;
          row.cells[m].innerText = count; // always show number (even 0)
        }
      });

      // Compute TOTAL row (Monthly)
      const totalRow = monthlyRows[monthlyRows.length - 1];
      for (let m = 1; m <= 12; m++) {
        let total = 0;
        monthlyRows.forEach((row, idx) => {
          if (idx < monthlyRows.length - 1) {
            total += parseInt(row.cells[m].innerText || 0);
          }
        });
        totalRow.cells[m].innerText = total;
      }

      // -------------------------------
      // Fill TIME REPORT
      // -------------------------------
      const timeRows = document.querySelectorAll('#timeReportTable tbody tr');
      timeRows.forEach(row => {
        const label = row.cells[0].innerText.trim();
        if (label.toLowerCase().includes('total')) return;

        for (let m = 1; m <= 12; m++) {
          const count = (timeData[label] && timeData[label][m]) ? timeData[label][m] : 0;
          row.cells[m].innerText = count; // always show number (even 0)
        }
      });

      // Compute TOTAL row (By Time)
      const totalTimeRow = timeRows[timeRows.length - 1];
      for (let m = 1; m <= 12; m++) {
        let total = 0;
        timeRows.forEach((row, idx) => {
          if (idx < timeRows.length - 1) {
            total += parseInt(row.cells[m].innerText || 0);
          }
        });
        totalTimeRow.cells[m].innerText = total;
      }
    })
    .catch(err => console.error('Error loading report:', err));

  // ✅ Download as PDF (Legal size, single page)
  document.getElementById('downloadPDF').addEventListener('click', function() {
    const element = document.createElement('div');
    element.style.width = '100%';
    element.style.textAlign = 'center';
    element.style.pageBreakInside = 'avoid';

    const titleClone = document.getElementById('reportTitle').cloneNode(true);
    const tableClone = (reportType.value === 'monthly')
      ? document.getElementById('monthlyReportTable').cloneNode(true)
      : document.getElementById('timeReportTable').cloneNode(true);

    titleClone.style.marginBottom = '10px';
    titleClone.style.fontSize = '18px';
    titleClone.style.fontWeight = 'bold';
    titleClone.style.pageBreakAfter = 'avoid';
    tableClone.style.pageBreakBefore = 'avoid';

    element.appendChild(titleClone);
    element.appendChild(tableClone);

    const opt = {
      margin: [5, 5, 5, 5],
      filename: 'Statistical_Report.pdf',
      html2canvas: { scale: 1 },
      jsPDF: { unit: 'mm', format: [355.6, 215.9], orientation: 'landscape' }, // 8.5x14 Legal
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
    };

    html2pdf().set(opt).from(element).save();
  });

  // ✅ Download as Excel
  document.getElementById('downloadExcel').addEventListener('click', function() {
    const table = (reportType.value === 'monthly') ? monthlyTable : timeTable;
    const wb = XLSX.utils.table_to_book(table, { sheet: "Report" });
    XLSX.writeFile(wb, 'Statistical_Report.xlsx');
  });
</script>

  <!-- Rankings Modal -->
  <div class="modal" id="rankingsModal">
    <div class="modal-content">
      <span class="close" onclick="closeRankingsModal()">&times;</span>
      <div class="modal-header-container">
        <div>
          <h3 class="modal-header">Rangkings</h3>
          <p id="chart-description">Top 5 Students with Most Visits in Library</p>
        </div>
        <div class="dropdown-container">
          <select id="viewType" onchange="changeRankingsView()">
            <option value="student">Student</option>
            <option value="course">Course</option>
          </select>
        </div>
      </div>
      <div class="modal-body">
        <!-- Container for the chart only -->
        <div class="chart-container">
          <canvas id="libraryChart"></canvas>
        </div>

        <!-- Download Button centered -->
        <div class="download-btn-container">
          <button onclick="downloadRankingsChart()">Download Chart</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Rankings Modal JavaScript -->
  <script>
    let libraryChart;
    let currentRankingsView = 'student'; // Track current view type

    function openRankingsModal() {
      document.getElementById("rankingsModal").style.display = "block";
      document.getElementById("viewType").value = 'student'; // Reset to student view
      currentRankingsView = 'student';
      
      // Trigger confetti explosion for 2 seconds
      triggerConfetti();
      
      renderRankingsChart(); // Render the chart when modal is opened
    }

    function triggerConfetti() {
      const duration = 2000; // 2 seconds
      const end = Date.now() + duration;
      const colors = ['#800020', '#A00030', '#FFD700', '#FFA500', '#FF6347']; // Maroon and festive colors

      (function frame() {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: colors
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: colors
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      }());
    }

    function changeRankingsView() {
      const viewType = document.getElementById("viewType").value;
      currentRankingsView = viewType;
      renderRankingsChart(); // Re-render chart with new view
    }

    function closeRankingsModal() {
      document.getElementById("rankingsModal").style.display = "none";
    }

    // Close the modal if clicked outside of the modal content
    window.onclick = function(event) {
      const modal = document.getElementById("rankingsModal");
      if (event.target == modal) {
        closeRankingsModal();
      }
    }

    // Function to render the bar graph using Chart.js
    function renderRankingsChart() {
      // Destroy existing chart if it exists
      if (libraryChart) {
        libraryChart.destroy();
      }

      // Determine which endpoint to fetch based on current view
      const endpoint = currentRankingsView === 'student' ? 'get_top_students.php' : 'get_top_courses.php';
      
      fetch(endpoint)
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            let labels, visitCounts, xAxisTitle, description;
            
            if (currentRankingsView === 'student' && data.students) {
              // Extract student names and visit counts
              labels = data.students.map(student => student.name || 'N/A');
              visitCounts = data.students.map(student => student.login_count || 0);
              xAxisTitle = 'Students';
              description = 'Top 5 Students with Most Visits in Library';
              
              // Update description
              document.getElementById('chart-description').textContent = description;
              
              // Create chart with student data
              createRankingsChart(labels, visitCounts, xAxisTitle, data.students, 'student');
            } else if (currentRankingsView === 'course' && data.courses) {
              // Extract course names and visit counts
              labels = data.courses.map(course => course.course || 'N/A');
              visitCounts = data.courses.map(course => course.visit_count || 0);
              xAxisTitle = 'Courses';
              description = 'Top 5 Courses with Most Visits in Library';
              
              // Update description
              document.getElementById('chart-description').textContent = description;
              
              // Create chart with course data
              createRankingsChart(labels, visitCounts, xAxisTitle, data.courses, 'course');
            } else {
              console.error('Error fetching data:', data);
              alert('Error loading data. Please try again.');
            }
          } else {
            console.error('Error fetching data:', data);
            alert('Error loading data. Please try again.');
          }
        })
        .catch(error => {
          console.error('Error fetching data:', error);
          alert('Error loading data. Please check your connection and try again.');
        });
    }

    // Function to create the chart
    function createRankingsChart(labels, visitCounts, xAxisTitle, dataArray, viewType) {
      var ctx = document.getElementById('libraryChart').getContext('2d');
      
      // Configure tooltip based on view type
      let tooltipCallback = null;
      if (viewType === 'student') {
        const studentIds = dataArray.map(item => item.student_id || '');
        const courses = dataArray.map(item => item.course || '');
        tooltipCallback = function(context) {
          const index = context.dataIndex;
          const studentId = studentIds[index];
          const course = courses[index];
          return `Student ID: ${studentId || 'N/A'}\nCourse: ${course || 'N/A'}`;
        };
      } else {
        tooltipCallback = function(context) {
          const index = context.dataIndex;
          const visitCount = visitCounts[index];
          return `Total Visits: ${visitCount || 0}`;
        };
      }
      
      libraryChart = new Chart(ctx, {
        type: 'bar', // Bar chart type
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Number of Visits in Library',
              data: visitCounts,
              backgroundColor: 'rgba(128, 0, 32, 0.6)', // Maroon color matching PUP theme
              borderColor: 'rgba(128, 0, 32, 1)',
              borderWidth: 2,
            }
          ]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'Number of Visits in Library'
              }
            },
            x: {
              title: {
                display: true,
                text: xAxisTitle
              },
              ticks: {
                maxRotation: 0, // Horizontal labels
                minRotation: 0,  // Horizontal labels
                autoSkip: false // Show all labels
              }
            }
          },
          responsive: true,
          maintainAspectRatio: false, // Allow chart to fill container
          plugins: {
            legend: {
              display: true,
              position: 'top'
            },
            tooltip: {
              callbacks: {
                afterLabel: tooltipCallback
              }
            }
          }
        }
      });
    }

    // Function to download the chart as a PNG image
    function downloadRankingsChart() {
      if (!libraryChart) {
        alert('Please wait for the chart to load.');
        return;
      }
      var imageUrl = libraryChart.toBase64Image(); // Get the chart as an image
      var link = document.createElement('a');
      link.href = imageUrl;
      const filename = currentRankingsView === 'student' ? 'top_5_students_visits.png' : 'top_5_courses_visits.png';
      link.download = filename; // Set the default download name
      link.click(); // Trigger the download
    }
  </script>

  <!-- Rankings Modal Styling -->
  <style>
    /* Rankings Modal specific styles */
    #rankingsModal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1000; /* Sit on top */
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0, 0, 0); /* Fallback color */
      background-color: rgba(0, 0, 0, 0.4); /* Black w/ opacity */
    }

    #rankingsModal .modal-content {
      background-color: #fefefe;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 90%;
      max-width: 1000px;
      position: relative;
    }

    #rankingsModal .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }

    #rankingsModal .close:hover,
    #rankingsModal .close:focus {
      color: black;
      text-decoration: none;
    }

    #rankingsModal .modal-header-container {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 10px;
    }

    #rankingsModal .modal-header {
      text-align: left;
      font-size: 24px;
      font-weight: bold;
      margin: 0;
      color: #555;
    }

    #rankingsModal .modal-body {
      text-align: left;
    }

    #rankingsModal .chart-container {
      margin-top: 20px;
      height: 500px;
      position: relative;
      width: 100%;
    }

    #rankingsModal .download-btn-container {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }

    #rankingsModal .download-btn-container button {
      border: none;
      color: #000;
      padding: 10px 15px;
      font-size: 14px;
      cursor: pointer;
      border-radius: 5px;
      background: #f9f9f9;
      border: 1px solid #ddd;
      transition: background 0.3s ease, transform 0.2s;
    }

    #rankingsModal .download-btn-container button:hover {
      background: #e2e2e2;
    }

    #rankingsModal .dropdown-container {
      margin-top: 5px;
      margin-right: 40px;
    }

    #rankingsModal .dropdown-container select {
      padding: 8px 12px;
      font-size: 14px;
      border: 1px solid #ddd;
      border-radius: 5px;
      background-color: #fff;
      cursor: pointer;
      font-family: Arial, sans-serif;
    }

    #rankingsModal .dropdown-container select:hover {
      border-color: #800020;
    }

    #rankingsModal .dropdown-container select:focus {
      outline: none;
      border-color: #800020;
      box-shadow: 0 0 5px rgba(128, 0, 32, 0.3);
    }

    #rankingsModal #chart-description {
      color: #555;
      margin: 0;
      padding: 0;
    }
  </style>

  <!-- Chart.js CDN -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <!-- Confetti.js CDN -->
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.2/dist/confetti.browser.min.js"></script>

  </div>

</body>
</html>
