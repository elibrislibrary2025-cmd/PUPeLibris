<?php
include 'connect.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['token'])) {
    $token = $_GET['token'];
    $newPassword = $_POST['new_password'];

    // Validate the token
    $stmt = $conn->prepare("SELECT * FROM password_resets WHERE token=? AND expires_at > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Get the associated email
        $row = $result->fetch_assoc();
        $email = $row['email'];

        // Update the password in the admin table
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE admin SET password=? WHERE email=?");
        $stmt->bind_param("ss", $hashedPassword, $email);
        $stmt->execute();

        // Optionally delete the token after use
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE token=?");
        $stmt->bind_param("s", $token);
        $stmt->execute();

        echo "<script>alert('Your password has been reset successfully.'); window.location.href = 'index.php';</script>";
    } else {
        echo "Invalid or expired token.";
    }
}
?>
