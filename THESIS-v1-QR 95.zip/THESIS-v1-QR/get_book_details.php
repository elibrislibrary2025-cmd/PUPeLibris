<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Ensure the response is JSON
header("Content-Type: application/json");

// Handle OPTIONS request (pre-flight request)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Include the database connection file
include('connect.php');

// Get the raw POST data
$data = json_decode(file_get_contents('php://input'), true);

// Retrieve the QR code data (which corresponds to the access number)
$qrCodeData = trim($data['qrCodeData']); // Remove leading/trailing spaces

// Log received data for debugging
error_log("Received QR Code Data: " . $qrCodeData);

// Prepare the SQL query to fetch book details based on the access number
$sql = "SELECT title, author, accessNumber, description FROM books WHERE accessNumber COLLATE utf8mb4_general_ci = ?";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Prepare failed: ' . $conn->error);  // Log and exit if prepare fails
}

// Bind the parameter
$stmt->bind_param('s', $qrCodeData);

// Execute the statement and check for errors
if ($stmt->execute()) {
    $stmt->bind_result($title, $author, $accessNumber, $description);

    // Check if the book was found
    if ($stmt->fetch()) {
        // Log if book is found
        error_log("Found book: " . $title);

        // Return the book details as JSON
        echo json_encode([
            'success' => true,
            'book' => [
                'title' => $title,
                'author' => $author,
                'accessNumber' => $accessNumber,
                'description' => $description ?? "No description available."
            ]
        ]);
    } else {
        // Log if no book was found
        error_log("Book not found for QR Code: " . $qrCodeData);

        // Return failure message
        echo json_encode(['success' => false, 'message' => 'Book not found']);
    }
} else {
    // Log SQL error
    error_log("Error executing query: " . $stmt->error);

    // Return error message
    echo json_encode(['success' => false, 'message' => 'Error executing query']);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
