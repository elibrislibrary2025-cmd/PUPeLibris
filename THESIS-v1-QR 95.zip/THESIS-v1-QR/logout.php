<?php
session_start();
session_unset();
session_destroy();

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// Redirect to login page
echo '<script type="text/javascript">
        window.location.href = "index.php";
        window.history.pushState(null, "", "index.php");
        window.onpopstate = function() {
            window.location.href = "index.php";
        };
      </script>';
exit();
?>
