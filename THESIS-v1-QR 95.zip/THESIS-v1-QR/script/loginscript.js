// script.js

document.addEventListener('DOMContentLoaded', () => {
    // Get references to the form containers
    const signUpContainer = document.getElementById('signup');
    const signInContainer = document.getElementById('signIn');

    // Get references to the buttons
    const signUpButton = document.getElementById('signUpButton');
    const signInButton = document.getElementById('signInButton');

    // Get references to the registration form and admin key input
    const registrationForm = document.getElementById('registrationForm');
    const adminKeyInput = document.getElementById('key');
    const errorMessage = document.getElementById('error-message');

    // Define the correct admin key (for client-side demo purposes)
    const correctAdminKey = '12345'; // Hard-coded admin key for demo

    // Function to show the Sign Up form and hide the Sign In form
    function showSignUp() {
        signInContainer.style.display = 'none';
        signUpContainer.style.display = 'block';
    }

    // Function to show the Sign In form and hide the Sign Up form
    function showSignIn() {
        signUpContainer.style.display = 'none';
        signInContainer.style.display = 'block';
    }

    // Function to handle form submission
    function handleFormSubmit(event) {
        // Get the entered admin key
        const enteredAdminKey = adminKeyInput.value;

        // Validate the admin key
        if (enteredAdminKey !== correctAdminKey) {
            // Prevent the form from being submitted
            event.preventDefault();

            // Show the error message
            errorMessage.style.display = 'block';
        } else {
            // Hide the error message (if previously displayed)
            errorMessage.style.display = 'none';
        }
    }

    // Attach event listeners to the buttons
    signUpButton.addEventListener('click', showSignUp);
    signInButton.addEventListener('click', showSignIn);

    // Attach event listener to the registration form
    registrationForm.addEventListener('submit', handleFormSubmit);

    // Initialize the view to show the Sign In form by default
    showSignIn();
});
