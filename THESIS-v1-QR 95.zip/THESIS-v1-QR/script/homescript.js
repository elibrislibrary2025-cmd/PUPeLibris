document.addEventListener('DOMContentLoaded', () => {
  let books = []; // Declare books array globally
  let students = []; // Declare students array globally

  const modal = document.getElementById('myModal'); // Modal element
  const closeModalButton = document.querySelector('.close'); // Close button for modal
  const modalBody = document.querySelector('.modal-body'); // Modal body where details are displayed
  const bookGenerateBtn = document.querySelector("#generate-book-qr");
  const studentGenerateBtn = document.querySelector("#generate-student-qr");
  const sidePanelButtons = document.querySelectorAll('.side-panel button');
  const panels = document.querySelectorAll('.main-content .panel');

  // Initialize with the saved or default active panel
  const savedPanel = localStorage.getItem('activePanel') || 'dashboard';
  showPanel(savedPanel);
  loadData(); // Load data when the page loads

  // Function to generate Student QR Code and send to PHP
  studentGenerateBtn.addEventListener("click", () => {
    const name = document.querySelector("#student-name").value.trim();
    const id = document.querySelector("#student-id").value.trim();
    const course = document.querySelector("#student-course").value.trim();
    const contact = document.querySelector("#student-contact").value.trim();
    const gmail = document.querySelector("#student-gmail").value.trim();

    if (!name || !id || !course || !contact || !gmail) {
      alert("Please fill out all fields!");
      return;
    }

    // Validate student ID (exactly 9 characters)
    if (id.length !== 15) {
      alert("Student ID must be exactly 15 characters long.");
      return;
    }

    // Validate student contact number (must be 11 digits)
    if (!/^\d{11}$/.test(contact)) {
      alert("Contact Number must be exactly 11 digits.");
      return;
    }

    // Validate Gmail (must be a valid Gmail address)
    const gmailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!gmailRegex.test(gmail)) {
      alert("Please enter a valid Gmail address (e.g., example@gmail.com)."); 
      return;
    }

      // Check if Student ID is unique
  checkStudentIdUniqueness(id).then(isUnique => {
    if (!isUnique) {
      alert("Error saving student data: The Student ID already exists.");
      return; // Stop the execution if the ID is not unique
    }

    const qrValue = `Name: ${name}\nID: ${id}\nCourse: ${course}\nContact: ${contact}\nGmail: ${gmail}`;
    const qrImg = document.querySelector("#student-qrImage");
    qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrValue)}`;

    saveStudentToDatabase(name, id, course, contact, gmail, qrImg.src);
  }).catch(error => {
    console.error("Error checking student ID uniqueness:", error);
    alert("Student ID already exists.");
  });
});

   // Function to check if Student ID is unique
function checkStudentIdUniqueness(studentId) {
  return new Promise((resolve, reject) => {
    fetch('check_student_id.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        student_id: studentId
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.exists) {
        resolve(false);  // Student ID already exists
      } else {
        resolve(true);   // Student ID is unique
      }
    })
    .catch(error => {
      console.error("Error checking student ID:", error);
      reject(error);
    });
  });
}


  // Function to save student data to PHP
  function saveStudentToDatabase(name, id, course, contact, gmail, qrCode) {
    fetch('database.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        save_student: true,
        name: name,
        id: id,
        course: course,
        contact: contact,
        gmail: gmail,
        qrCode: qrCode
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert("Student saved successfully!");
        // Persist target panel and reload the page without leaving the Student QR panel
        localStorage.setItem('activePanel', 'student-qr-generator');
        location.reload();
      } else {
        alert("Error saving student data: " + data.message);
      }
    })
    .catch(error => console.error("Error:", error));
  }

  // Function to generate Book QR Code and send to PHP
  bookGenerateBtn.addEventListener("click", () => {
    const title = document.querySelector("#book-title").value.trim();
    const author = document.querySelector("#book-author").value.trim();
    const accessNumber = document.querySelector("#access-number").value.trim();
    const description = document.querySelector("#book-description").value.trim();

    if (!title || !author || !accessNumber || !description) {
      alert("Please fill out all fields!");
      return;
    }

      // Validate Access Number uniqueness
  checkAccessNumberUniqueness(accessNumber).then(isUnique => {
    if (!isUnique) {
      alert("Error: The Access Number is already in use. Please use a unique Access Number.");
      return; // Stop the execution if the Access Number is not unique
    }

    // Create the QR code value
    const qrValue = `Title: ${title}\nAuthor: ${author}\nDescription: ${description}\nAccessNumber: ${accessNumber}`;
    const qrImg = document.querySelector("#book-qrImage");

    qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrValue)}`;

    saveBookToDatabase(title, author, description, accessNumber, qrImg.src);
  }).catch(error => {
    console.error("Error checking access number:", error);
    alert("Book Accession already exists.");
  });
});

  // Function to check if Access Number is unique
  function checkAccessNumberUniqueness(accessNumber) {
    return new Promise((resolve, reject) => {
      fetch('check_access_number.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ access_number: accessNumber })
      })
      .then(response => response.json())
      .then(data => {
        if (data.exists) {
          resolve(false);  // Access Number already exists
        } else {
          resolve(true);   // Access Number is unique
        }
      })
      .catch(error => {
        console.error("Error checking access number:", error);
        reject(error);
      });
    });
  }

  // Function to save book data to PHP
  function saveBookToDatabase(title, author, description, accessNumber, qrCode) {
    fetch('database.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        save_book: true,
        accessNumber: accessNumber,
        title: title,
        author: author,
        description: description,
        qrCode: qrCode
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert("Book saved successfully!");
        // Persist target panel and reload the page without leaving the Book QR panel
        localStorage.setItem('activePanel', 'book-qr-generator');
        location.reload();
      } else {
        if (data.message === "Access Number already exists") {
          alert("Error: The Access Number is already in use.");
        } else {
          alert("Error saving book data: " + data.message);
        }
      }
    })
    .catch(error => console.error("Error:", error));
  }

  // Function to load data from the database and display it
  function loadData() {
    fetch('fetch_data.php')
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          books = data.books; // Save books data globally
          console.log(books);
          students = data.students; // Save students data globally
          console.log(students);
          displayBookInventory(data.books);
          displayStudentList(data.students);
        } else {
          console.error("Failed to fetch data");
        }
      })
      .catch(error => console.error("Error fetching data:", error));
  }

  // Function to display the book inventory
  function displayBookInventory(books) {
    const inventoryTable = document.querySelector("#inventory-table tbody");
    inventoryTable.innerHTML = ''; // Clear existing data
    books.forEach(book => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td class="details-container">
          ${book.title}
        </td>
        <td>
          <img src="${book.qrCode}" alt="QR Code" class="qr-code">
        </td>
        <td class="button-container">
          <button class="details-btn" data-access-number="${book.accessNumber}">Details</button>
          <button class="delete-btn" data-access-number="${book.accessNumber}">Delete</button>
        </td>
      `;
      inventoryTable.appendChild(row);
    });

    // Add event listeners for the buttons dynamically
    addEventListeners();
  }

  // Function to display the student list
 // Function to display the student list with search bar
function displayStudentList(students) {
    const studentPanel = document.querySelector("#student-list .scrollable-table");
    studentPanel.innerHTML = ''; // Clear existing table content

    // Create search input
    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.placeholder = 'Search Student';
    searchInput.id = 'student-search';
    searchInput.className = 'search-input';
    searchInput.style = 'margin-bottom: 10px; padding:5px; width:100%;';
    studentPanel.appendChild(searchInput);

    // Create table
    const table = document.createElement('table');
    table.id = 'student-table';
    const tbody = document.createElement('tbody');
    table.appendChild(tbody);
    studentPanel.appendChild(table);

    // Populate table rows
    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="details-container">${student.name}</td>
            <td><img src="${student.qrCode}" alt="QR Code" class="qr-code"></td>
            <td class="button-container">
                <button class="details-btn" data-id="${student.student_id}">Details</button>
                <button class="delete-btn" data-id="${student.student_id}">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });

    // Add event listeners to buttons
    addEventListeners();

    // Add search functionality
    searchInput.addEventListener('keyup', function() {
        const filter = searchInput.value.toLowerCase();
        Array.from(tbody.getElementsByTagName('tr')).forEach(row => {
            const nameCell = row.getElementsByTagName('td')[0];
            if (nameCell) {
                const text = nameCell.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            }
        });
    });
}


  // Add event listeners to dynamically added buttons
  function addEventListeners() {
    const deleteButtons = document.querySelectorAll('.delete-btn');
    const detailsButtons = document.querySelectorAll('.details-btn');

    deleteButtons.forEach(button => {
      button.addEventListener('click', (event) => {
        const id = event.target.getAttribute('data-id') || event.target.getAttribute('data-access-number');
        const isBook = event.target.hasAttribute('data-access-number'); // Check if it's a book or student
        if (isBook) {
          deleteBook(id);
        } else {
          deleteStudent(id);
        }
      });
    });

    detailsButtons.forEach(button => {
      button.addEventListener('click', (event) => {
        const id = event.target.getAttribute('data-id') || event.target.getAttribute('data-access-number');
        const isBook = event.target.hasAttribute('data-access-number'); // Check if it's a book or student
        if (isBook) {
          showBookDetails(id);
        } else {
          showStudentDetails(id);
        }
      });
    });
  }

  // Function to show book details in the modal
  window.showBookDetails = function(accessNumber) {
    const book = books.find(b => b.accessNumber === accessNumber); // Find the book by access number
    
    if (book) {
      modalBody.innerHTML = `
        <h3>Title: ${book.title}</h3>
        <p>Author: ${book.author}</p>
        <p>Description: ${book.description}</p>
        <p>Access Number: ${book.accessNumber}</p>
        <img src="${book.qrCode}" alt="QR Code">
      `;
      modal.style.display = 'block'; // Show the modal
    }
  };

  // Function to show student details in the modal
  window.showStudentDetails = function(id) {
    const student = students.find(s => s.student_id === id); // Find the student by ID
    
    if (student) {
      modalBody.innerHTML = `
        <h3>Name: ${student.name}</h3>
        <p>Student ID: ${student.student_id}</p>
        <p>Course: ${student.course}</p>
        <p>Contact: ${student.contact}</p>
        <p>Email: ${student.gmail}</p>
        <img src="${student.qrCode}" alt="QR Code">
      `;
      modal.style.display = 'block'; // Show the modal
    }
  };

  // Close the modal when the user clicks on <span> (x)
  closeModalButton.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  // Close the modal if the user clicks outside of it
  window.onclick = function(event) {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  };

// Function to delete a book
window.deleteBook = function(accessNumber) {
  if (confirm("Are you sure you want to delete this book?")) {
      fetch('database.php', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify({
              delete_book: true,
              accessNumber: accessNumber
          })
      })
      .then(response => response.json())
      .then(data => {
          if (data.success) {
              alert("Book deleted successfully!");
              loadData(); // Reload data after deleting
          } else {
              alert("Error deleting book: " + data.message);
          }
      })
      .catch(error => console.error("Error:", error));
  }
};

// Function to delete a student
window.deleteStudent = function(id) {
  if (confirm("Are you sure you want to delete this student?")) {
      fetch('database.php', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify({
              delete_student: true,
              id: id
          })
      })
      .then(response => response.json())
      .then(data => {
          if (data.success) {
              alert("Student deleted successfully!");
              loadData(); // Reload data after deleting
          } else {
              alert("Error deleting student: " + data.message);
          }
      })
      .catch(error => console.error("Error:", error));
  }
};

  // Function to show the selected panel
  function showPanel(panelId) {
    panels.forEach(panel => {
      if (panel.id === panelId) {
        panel.classList.add('active');
      } else {
        panel.classList.remove('active');
      }
    });

    // Set the active button
    sidePanelButtons.forEach(button => {
      if (button.id === `${panelId}-btn`) {
        button.classList.add('active');
      } else {
        button.classList.remove('active');
      }
    });
    // Persist current panel selection
    try { localStorage.setItem('activePanel', panelId); } catch (e) {}
  }

  // Adding click event listeners to side panel buttons
  sidePanelButtons.forEach(button => {
    button.addEventListener('click', () => {
      const panelId = button.id.replace('-btn', ''); // Extract panel ID from button ID
      showPanel(panelId);
    });
  });
});
