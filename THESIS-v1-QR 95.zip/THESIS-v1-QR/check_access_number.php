<?php
// Database connection
include('connect.php');

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

// Check if the access number is provided
if(isset($data['access_number'])) {
    $accessNumber = $data['access_number'];

    // Prepare the SQL query to check for existing access number
    $query = "SELECT COUNT(*) AS count FROM books WHERE accessNumber = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $accessNumber);  // "s" denotes string type
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();

    // Send response based on the result
    if($count > 0) {
        // Access number exists
        echo json_encode(["exists" => true]);
    } else {
        // Access number does not exist
        echo json_encode(["exists" => false]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "Access number is required."]);
}

$conn->close();
?>
