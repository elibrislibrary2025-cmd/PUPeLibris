<?php
date_default_timezone_set('Asia/Manila');
include('connect.php');

header('Content-Type: application/json');

// Collect the POST data
$student_id = $_POST['student_id'] ?? '';
$name = $_POST['name'] ?? '';
$course = $_POST['course'] ?? '';
$reason = $_POST['reason'] ?? '';
$date = $_POST['attendance_date'] ?? date('Y-m-d');
$time = $_POST['attendance_time'] ?? date('H:i:s'); // Use 24-hour format for consistency

// Validate required fields
if (empty($student_id) || empty($reason)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
    exit();
}

// Auto-fetch missing name or course if not provided
if (empty($name) || empty($course)) {
    $stmt = $conn->prepare("SELECT name, course FROM students WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        $name = $student['name'] ?? 'Unknown';
        $course = $student['course'] ?? 'Unknown';
    }
    $stmt->close();
}

// Prepare the SQL statement to insert the attendance record
$sql = "INSERT INTO attendance (student_id, name, course, reason, attendance_date, attendance_time) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $student_id, $name, $course, $reason, $date, $time);

// Execute and handle success or failure
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Attendance saved successfully!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error saving attendance: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
