<?php
include 'connect.php';
header('Content-Type: application/json');
date_default_timezone_set('Asia/Manila');

// Current year filter
$current_year = date('Y');

// -----------------------------
// FETCH: Attendance count by course per month
// -----------------------------
$monthly_sql = "
    SELECT 
        course,
        MONTH(attendance_date) AS month,
        COUNT(*) AS total
    FROM attendance
    WHERE YEAR(attendance_date) = '$current_year'
    GROUP BY course, MONTH(attendance_date)
";
$monthly_result = $conn->query($monthly_sql);

$monthly_data = [];
if ($monthly_result && $monthly_result->num_rows > 0) {
    while ($row = $monthly_result->fetch_assoc()) {
        $course = strtoupper(trim($row['course'])); // acronym uppercase
        $month = (int)$row['month'];
        $monthly_data[$course][$month] = (int)$row['total'];
    }
}

// -----------------------------
// FETCH: Attendance count by time range per month
// -----------------------------
$time_sql = "
    SELECT 
        MONTH(attendance_date) AS month,
        attendance_time
    FROM attendance
    WHERE YEAR(attendance_date) = '$current_year'
";
$time_result = $conn->query($time_sql);

$time_data = [];
$time_ranges = [
    "8:00 - 9:00 AM" => ['08:00:00', '09:00:00'],
    "9:01 - 10:00 AM" => ['09:01:00', '10:00:00'],
    "10:01 - 11:00 AM" => ['10:01:00', '11:00:00'],
    "11:01 - 12:00 NN" => ['11:01:00', '12:00:00'],
    "12:01 - 1:00 PM" => ['12:01:00', '13:00:00'],
    "1:01 - 2:00 PM" => ['13:01:00', '14:00:00'],
    "2:01 - 3:00 PM" => ['14:01:00', '15:00:00'],
    "3:01 - 4:00 PM" => ['15:01:00', '16:00:00'],
    "4:01 - 5:00 PM" => ['16:01:00', '17:00:00'],
    "5:01 - 6:00 PM" => ['17:01:00', '18:00:00']
];

if ($time_result && $time_result->num_rows > 0) {
    while ($row = $time_result->fetch_assoc()) {
        $time_str = date("H:i:s", strtotime($row['attendance_time']));
        $month = (int)$row['month'];
        foreach ($time_ranges as $label => [$start, $end]) {
            if ($time_str >= $start && $time_str <= $end) {
                if (!isset($time_data[$label][$month])) {
                    $time_data[$label][$month] = 0;
                }
                $time_data[$label][$month]++;
            }
        }
    }
}

// -----------------------------
// ENSURE: All months (1–12) exist and default to 0
// -----------------------------

// For Monthly data
foreach ($monthly_data as $course => &$months) {
    for ($m = 1; $m <= 12; $m++) {
        if (!isset($months[$m])) {
            $months[$m] = 0;
        }
    }
}
unset($months); // cleanup reference

// For Time data
foreach ($time_ranges as $label => $_) {
    if (!isset($time_data[$label])) $time_data[$label] = [];
    for ($m = 1; $m <= 12; $m++) {
        if (!isset($time_data[$label][$m])) {
            $time_data[$label][$m] = 0;
        }
    }
}

// -----------------------------
// OUTPUT JSON
// -----------------------------
echo json_encode([
    'monthly' => $monthly_data,
    'time' => $time_data
], JSON_PRETTY_PRINT);

$conn->close();
?>
