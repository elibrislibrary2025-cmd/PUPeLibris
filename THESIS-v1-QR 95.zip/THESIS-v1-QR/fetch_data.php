<?php
// Connect to the database
include 'connect.php';

// Initialize an empty array for results
$response = ['success' => false, 'books' => [], 'students' => []];

// Handle delete request for books
if (isset($_POST['delete_book'])) {
    $accessNumber = $_POST['accessNumber'];
    $deleteBookQuery = "DELETE FROM books WHERE accessNumber = ?";
    $stmt = $conn->prepare($deleteBookQuery);
    $stmt->bind_param("s", $accessNumber);
    $stmt->execute();
    $response['success'] = $stmt->affected_rows > 0;
    $stmt->close();
    echo json_encode($response);
    exit;
}

// Handle delete request for students
if (isset($_POST['delete_student'])) {
    $id = $_POST['id'];
    $deleteStudentQuery = "DELETE FROM students WHERE id = ?";
    $stmt = $conn->prepare($deleteStudentQuery);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $response['success'] = $stmt->affected_rows > 0;
    $stmt->close();
    echo json_encode($response);
    exit;
}

// Fetch books from the database
$bookQuery = "SELECT title, author, description, accessNumber, qrCode FROM books";
$bookResult = $conn->query($bookQuery);

if ($bookResult && $bookResult->num_rows > 0) {
    while ($row = $bookResult->fetch_assoc()) {
        $response['books'][] = $row;
    }
}

// Fetch students from the database
$studentQuery = "SELECT name, student_id, course, contact, gmail, qrCode FROM students";
$studentResult = $conn->query($studentQuery);

if ($studentResult && $studentResult->num_rows > 0) {
    while ($row = $studentResult->fetch_assoc()) {
        $response['students'][] = $row;
    }
}

// Set success to true if data was retrieved
$response['success'] = true;

// Return data as JSON
echo json_encode($response);
?>
