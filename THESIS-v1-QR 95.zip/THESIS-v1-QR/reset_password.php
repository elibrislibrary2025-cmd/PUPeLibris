<?php
include 'connect.php'; // Include your database connection

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $stmt = $conn->prepare("SELECT * FROM password_resets WHERE token=? AND expires_at > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Show reset password form
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Reset Password</title>
            <link rel="stylesheet" type="text/css" href="css/style.css">
        </head>
        <body>
            <div class="container">
                <h1>Reset Your Password</h1>
                <form method="post" action="update_password.php?token=<?php echo $token; ?>">
                    <div class="input-group">
                        <input type="password" name="new_password" placeholder="New Password" required>
                    </div>
                    <input type="submit" class="btn" value="Reset Password">
                </form>
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "Invalid or expired token.";
    }
}
?>
