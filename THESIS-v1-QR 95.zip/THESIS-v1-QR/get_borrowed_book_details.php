<?php
include 'connect.php'; // Include your database connection file

header('Content-Type: application/json');

// Decode the incoming JSON input
$input = json_decode(file_get_contents('php://input'), true);
$accessNumber = $input['qrCodeData'] ?? null;

if ($accessNumber) {
    // Prepare SQL query to fetch the most recent borrowed record
    $query = $conn->prepare("
        SELECT 
            book_title, 
            book_author, 
            access_number, 
            book_description,
            student_id, 
            name, 
            course, 
            contact_number, 
            email, 
            borrowed_date
        FROM borrowed_books
        WHERE access_number = ?
        ORDER BY borrowed_date DESC
        LIMIT 1
    ");
    
    $query->bind_param("s", $accessNumber);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        $borrowedBook = $result->fetch_assoc();
        echo json_encode(['success' => true, 'borrowedBook' => $borrowedBook]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No borrowed book found with the provided access number.']);
    }

    $query->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid access number provided.']);
}

$conn->close();
?>
