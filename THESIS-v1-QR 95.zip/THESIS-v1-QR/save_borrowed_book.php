<?php

date_default_timezone_set('Asia/Manila');
// Include your database connection file
include("connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data from POST request
    $bookTitle = mysqli_real_escape_string($conn, $_POST['bookTitle']);
    $bookAuthor = mysqli_real_escape_string($conn, $_POST['bookAuthor']);
    $accessNumber = mysqli_real_escape_string($conn, $_POST['accessNumber']);
    $bookDescription = mysqli_real_escape_string($conn, $_POST['bookDescription']);
    $studentId = mysqli_real_escape_string($conn, $_POST['studentId']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $contactNumber = mysqli_real_escape_string($conn, $_POST['contactNumber']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

// Get the current date and time in 12-hour format with AM/PM
$borrowedDate = date("Y-m-d h:i:s A");  // Format: 2024-11-22 03:45:00 PM

// SQL query to insert the borrowed book data along with the formatted borrowed_date
$query = "INSERT INTO borrowed_books (book_title, book_author, access_number, book_description, student_id, name, course, contact_number, email, borrowed_date) 
          VALUES ('$bookTitle', '$bookAuthor', '$accessNumber', '$bookDescription', '$studentId', '$name', '$course', '$contactNumber', '$email', '$borrowedDate')";


    // Execute the query
    if (mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Book borrowed successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error borrowing book: ' . mysqli_error($conn)]);
    }

    // Close the connection
    mysqli_close($conn);
}
?>
