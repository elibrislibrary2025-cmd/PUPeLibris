<?php
include 'connect.php';
header('Content-Type: application/json');
date_default_timezone_set('Asia/Manila');

// Query to get top 5 students with most log-ins
$sql = "
    SELECT 
        student_id,
        name,
        course,
        COUNT(*) as login_count
    FROM attendance
    GROUP BY student_id, name, course
    ORDER BY login_count DESC
    LIMIT 5
";

$result = $conn->query($sql);

$top_students = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $top_students[] = [
            'student_id' => $row['student_id'],
            'name' => $row['name'],
            'course' => $row['course'],
            'login_count' => (int)$row['login_count']
        ];
    }
}

// If less than 5 students, pad with empty data
while (count($top_students) < 5) {
    $top_students[] = [
        'student_id' => '',
        'name' => 'N/A',
        'course' => '',
        'login_count' => 0
    ];
}

echo json_encode([
    'success' => true,
    'students' => $top_students
], JSON_PRETTY_PRINT);

$conn->close();
?>

