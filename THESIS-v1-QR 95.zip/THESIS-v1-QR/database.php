    <?php
    header("Content-Type: application/json");
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Include database connection
    include 'connect.php';

    // Get the JSON input
    $input = json_decode(file_get_contents("php://input"), true);

    // Log the input for debugging
    file_put_contents('debug.log', print_r($input, true), FILE_APPEND);

    // Save book fetch data function
    if (isset($input['save_book'])) {
        $title = $input['title'];
        $author = $input['author'];
        $description = $input['description'];
        $accessNumber = $input['accessNumber'];
        $qrCode = $input['qrCode'];

        // Prepare the SQL statement with unique constraint handling
        $stmt = $conn->prepare("INSERT INTO books (title, author, description, accessNumber, qrCode) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $title, $author, $description, $accessNumber, $qrCode);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        
        } else {
            // Check if the error is due to duplicate accessNumber
            if ($conn->errno == 1062) { // MySQL error code for duplicate entry
                echo json_encode(['success' => false, 'message' => 'Access Number already exists']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
            }
        }
        $stmt->close();
    // Save student fetch data function
    } elseif (isset($input['save_student'])) {
        $name = $input['name'];
        $id = $input['id'];
        $course = $input['course'];
        $contact = $input['contact'];
        $gmail = $input['gmail'];
        $qrCode = $input['qrCode'];

        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO students (name, student_id, course, contact, gmail, qrCode) VALUES (?, ?, ?, ?, ?, ?)");
        
        // Check for preparation errors
        if ($stmt === false) {
            die(json_encode(['success' => false, 'message' => 'MySQL prepare error: ' . $conn->error]));
        }

        // Bind parameters
        $stmt->bind_param("ssssss", $name, $id, $course, $contact, $gmail, $qrCode);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Execution error: ' . $stmt->error]);
        }

        // Close statement
        $stmt->close();
    }

    // Handle Delete Book
    elseif (isset($input['delete_book'])) {
        $accessNumber = $input['accessNumber'];

        // Log the accessNumber to debug if it's being passed correctly
        file_put_contents('debug.log', "Deleting book with accessNumber: " . $accessNumber . "\n", FILE_APPEND);

        // Prepare DELETE query
        $stmt = $conn->prepare("DELETE FROM books WHERE accessNumber = ?");
        $stmt->bind_param("s", $accessNumber);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error deleting book: ' . $stmt->error]);
        }

        $stmt->close();
    }

    // Handle Delete Student
    elseif (isset($input['delete_student'])) {
        $id = $input['id'];

        // Log the id to debug if it's being passed correctly
        file_put_contents('debug.log', "Deleting student with id: " . $id . "\n", FILE_APPEND);

        // Prepare DELETE query
        $stmt = $conn->prepare("DELETE FROM students WHERE student_id = ?");
        $stmt->bind_param("s", $id);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error deleting student: ' . $stmt->error]);
        }

        $stmt->close();
    }

//     // Handle Save Attendance
// elseif (isset($input['save_attendance'])) {
//     $student_id = $input['student_id'];
//     $name = $input['name'];
//     $course = $input['course'];
//     $reason = $input['reason'];
//     $attendance_date = $input['attendance_date'];
//     $attendance_time = $input['attendance_time'];

//     // Validate required fields
//     if (empty($student_id) || empty($reason)) {
//         echo json_encode(['success' => false, 'message' => 'Missing required fields']);
//         exit();
//     }

//     // Prepare the SQL statement to save attendance
//     $stmt = $conn->prepare("INSERT INTO attendance (student_id, name, course, reason, attendance_date, attendance_time) 
//                             VALUES (?, ?, ?, ?, ?, ?)");
//     $stmt->bind_param("ssssss", $student_id, $name, $course, $reason, $attendance_date, $attendance_time);

//     if ($stmt->execute()) {
//         echo json_encode(['success' => true, 'message' => 'Attendance saved successfully']);
//     } else {
//         echo json_encode(['success' => false, 'message' => 'Error saving attendance: ' . $stmt->error]);
//     }

//     $stmt->close();
// }

    $conn->close();
    ?>

